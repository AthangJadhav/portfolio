import { useRef } from "react"

type TopBarProps = {
  onContactClick: () => void
  onAdminTrigger: () => void
}

const TRIPLE_CLICK_WINDOW_MS = 2000

export function TopBar({ onContactClick, onAdminTrigger }: TopBarProps) {
  // Tracks the timestamps of recent clicks on the logo so we can
  // detect "3 clicks within 2 seconds" without any visible UI hint.
  const clickTimestamps = useRef<number[]>([])

  const handleLogoClick = () => {
    const now = Date.now()
    const recent = clickTimestamps.current.filter(
      (timestamp) => now - timestamp < TRIPLE_CLICK_WINDOW_MS,
    )
    recent.push(now)
    clickTimestamps.current = recent

    if (recent.length >= 3) {
      clickTimestamps.current = []
      onAdminTrigger()
    }
  }

  return (
    <header className="top-bar">
      <button
        type="button"
        className="top-bar__brand"
        onClick={handleLogoClick}
        aria-label="Athang Jadhav"
      >
        AJ
      </button>

      <button
        type="button"
        className="top-bar__contact"
        onClick={onContactClick}
      >
        Contact
      </button>
    </header>
  )
}
