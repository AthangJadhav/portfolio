import { useEffect, useState } from "react"
import type { Section, SiteContent } from "../lib/api"
import {
  createSection,
  deleteSection,
  fetchAdminSections,
  fetchAdminSite,
  logout,
  reorderSections,
  updateSection,
  updateSite,
} from "../lib/api"

type AdminDashboardProps = {
  onClose: () => void
  onContentChanged: () => void
}

const SITE_FIELDS: { key: keyof SiteContent; label: string; multiline?: boolean }[] = [
  { key: "heroName", label: "Hero name" },
  { key: "heroRole", label: "Hero role" },
  { key: "introEyebrow", label: "Work section eyebrow" },
  { key: "introHeading", label: "Work section heading" },
  { key: "contactEyebrow", label: "Contact eyebrow" },
  { key: "contactHeading", label: "Contact heading" },
  { key: "contactDescription", label: "Contact description", multiline: true },
  { key: "contactEmail", label: "Contact email" },
]

export function AdminDashboard({ onClose, onContentChanged }: AdminDashboardProps) {
  const [site, setSite] = useState<SiteContent | null>(null)
  const [sections, setSections] = useState<Section[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [savingSite, setSavingSite] = useState(false)

  const [newTitle, setNewTitle] = useState("")
  const [newCaption, setNewCaption] = useState("")
  const [newVideoFile, setNewVideoFile] = useState<File | null>(null)
  const [creating, setCreating] = useState(false)

  const loadAll = async () => {
    setLoading(true)
    setError(null)
    try {
      const [siteData, sectionsData] = await Promise.all([
        fetchAdminSite(),
        fetchAdminSections(),
      ])
      setSite(siteData)
      setSections(sectionsData)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load admin data.")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadAll()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleSiteFieldChange = (key: keyof SiteContent, value: string) => {
    setSite((current) => (current ? { ...current, [key]: value } : current))
  }

  const handleSaveSite = async () => {
    if (!site) return
    setSavingSite(true)
    setError(null)
    try {
      const updated = await updateSite(site)
      setSite(updated)
      onContentChanged()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save site content.")
    } finally {
      setSavingSite(false)
    }
  }

  const handleCreateSection = async () => {
    if (!newTitle.trim()) return
    setCreating(true)
    setError(null)
    try {
      await createSection({
        title: newTitle,
        caption: newCaption,
        isVisible: true,
        videoFile: newVideoFile,
      })
      setNewTitle("")
      setNewCaption("")
      setNewVideoFile(null)
      await loadAll()
      onContentChanged()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create section.")
    } finally {
      setCreating(false)
    }
  }

  const handleSectionFieldChange = (id: string, key: "title" | "caption", value: string) => {
    setSections((current) =>
      current.map((section) => (section.id === id ? { ...section, [key]: value } : section)),
    )
  }

  const handleSaveSection = async (id: string) => {
    const section = sections.find((s) => s.id === id)
    if (!section) return
    setError(null)
    try {
      const updated = await updateSection(id, {
        title: section.title,
        caption: section.caption,
      })
      setSections((current) => current.map((s) => (s.id === id ? updated : s)))
      onContentChanged()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save section.")
    }
  }

  const handleToggleVisibility = async (section: Section) => {
    setError(null)
    try {
      const updated = await updateSection(section.id, { isVisible: !section.isVisible })
      setSections((current) => current.map((s) => (s.id === section.id ? updated : s)))
      onContentChanged()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update visibility.")
    }
  }

  const handleReplaceVideo = async (id: string, file: File) => {
    setError(null)
    try {
      const updated = await updateSection(id, { videoFile: file })
      setSections((current) => current.map((s) => (s.id === id ? updated : s)))
      onContentChanged()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to upload video.")
    }
  }

  const handleDelete = async (id: string) => {
    if (!window.confirm("Delete this section? This can't be undone.")) return
    setError(null)
    try {
      await deleteSection(id)
      setSections((current) => current.filter((s) => s.id !== id))
      onContentChanged()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete section.")
    }
  }

  const handleMove = async (index: number, direction: -1 | 1) => {
    const targetIndex = index + direction
    if (targetIndex < 0 || targetIndex >= sections.length) return

    const reordered = [...sections]
    const [moved] = reordered.splice(index, 1)
    reordered.splice(targetIndex, 0, moved)
    setSections(reordered)

    setError(null)
    try {
      const updated = await reorderSections(reordered.map((s) => s.id))
      setSections(updated)
      onContentChanged()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to reorder sections.")
      await loadAll()
    }
  }

  const handleLogout = () => {
    logout()
    onClose()
  }

  return (
    <div className="admin-dashboard">
      <div className="admin-dashboard__header">
        <h2>Admin dashboard</h2>
        <div className="admin-dashboard__header-actions">
          <button
            type="button"
            onClick={handleLogout}
            className="admin-dashboard__logout"
          >
            Log out
          </button>
          <button
            type="button"
            onClick={onClose}
            className="admin-dashboard__close"
            aria-label="Close admin dashboard"
          >
            ×
          </button>
        </div>
      </div>

      {error && <p className="admin-dashboard__error">{error}</p>}

      {loading ? (
        <p className="admin-dashboard__loading">Loading…</p>
      ) : (
        <div className="admin-dashboard__body">
          <section className="admin-dashboard__section">
            <h3>Site content</h3>

            {site && (
              <div className="admin-dashboard__site-form">
                {SITE_FIELDS.map((field) =>
                  field.multiline ? (
                    <label key={field.key}>
                      {field.label}
                      <textarea
                        value={site[field.key]}
                        onChange={(event) =>
                          handleSiteFieldChange(field.key, event.target.value)
                        }
                      />
                    </label>
                  ) : (
                    <label key={field.key}>
                      {field.label}
                      <input
                        type="text"
                        value={site[field.key]}
                        onChange={(event) =>
                          handleSiteFieldChange(field.key, event.target.value)
                        }
                      />
                    </label>
                  ),
                )}

                <button
                  type="button"
                  onClick={handleSaveSite}
                  disabled={savingSite}
                  className="admin-dashboard__save"
                >
                  {savingSite ? "Saving…" : "Save site content"}
                </button>
              </div>
            )}
          </section>

          <section className="admin-dashboard__section">
            <h3>Add a section</h3>

            <div className="admin-dashboard__new-section">
              <label>
                Title
                <input
                  type="text"
                  value={newTitle}
                  onChange={(event) => setNewTitle(event.target.value)}
                  placeholder="e.g. Podcast Clips"
                />
              </label>

              <label>
                Description / caption
                <textarea
                  value={newCaption}
                  onChange={(event) => setNewCaption(event.target.value)}
                />
              </label>

              <label>
                Video file (optional for now)
                <input
                  type="file"
                  accept="video/mp4,video/webm,video/quicktime,video/x-matroska"
                  onChange={(event) => setNewVideoFile(event.target.files?.[0] ?? null)}
                />
              </label>

              <button
                type="button"
                onClick={handleCreateSection}
                disabled={creating || !newTitle.trim()}
                className="admin-dashboard__save"
              >
                {creating ? "Adding…" : "Add section"}
              </button>
            </div>
          </section>

          <section className="admin-dashboard__section">
            <h3>Sections ({sections.length})</h3>

            <ul className="admin-dashboard__sections-list">
              {sections.map((section, index) => (
                <li
                  key={section.id}
                  className="admin-section-row"
                >
                  <div className="admin-section-row__order">
                    <button
                      type="button"
                      onClick={() => handleMove(index, -1)}
                      disabled={index === 0}
                      aria-label="Move up"
                    >
                      ↑
                    </button>
                    <button
                      type="button"
                      onClick={() => handleMove(index, 1)}
                      disabled={index === sections.length - 1}
                      aria-label="Move down"
                    >
                      ↓
                    </button>
                  </div>

                  <div className="admin-section-row__fields">
                    <input
                      type="text"
                      value={section.title}
                      onChange={(event) =>
                        handleSectionFieldChange(section.id, "title", event.target.value)
                      }
                    />
                    <textarea
                      value={section.caption}
                      onChange={(event) =>
                        handleSectionFieldChange(section.id, "caption", event.target.value)
                      }
                    />

                    <div className="admin-section-row__video">
                      <span>{section.videoUrl ? "Video uploaded" : "No video yet"}</span>
                      <input
                        type="file"
                        accept="video/mp4,video/webm,video/quicktime,video/x-matroska"
                        onChange={(event) => {
                          const file = event.target.files?.[0]
                          if (file) handleReplaceVideo(section.id, file)
                        }}
                      />
                    </div>
                  </div>

                  <div className="admin-section-row__actions">
                    <label className="admin-section-row__toggle">
                      <input
                        type="checkbox"
                        checked={section.isVisible}
                        onChange={() => handleToggleVisibility(section)}
                      />
                      Visible
                    </label>

                    <button
                      type="button"
                      onClick={() => handleSaveSection(section.id)}
                    >
                      Save
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDelete(section.id)}
                      className="admin-section-row__delete"
                    >
                      Delete
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </section>
        </div>
      )}
    </div>
  )
}
