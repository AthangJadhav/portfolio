import { useEffect, useRef, useState } from "react"
import "./App.css"
import { TopBar } from "./components/TopBar"
import { WorkSidebar } from "./components/WorkSidebar"
import { VideoModal } from "./components/VideoModal"
import { LoginModal } from "./components/LoginModal"
import { AdminDashboard } from "./components/AdminDashboard"
import {
  fetchPublicSections,
  fetchPublicSite,
  isLoggedIn,
  type Section,
  type SiteContent,
} from "./lib/api"

type FloatingLetter = {
  char: string
  x: number
  y: number
  size: number
  rotation: number
  depth: number
}

const floatingLetters: FloatingLetter[] = [
  { char: "A", x: 8, y: 12, size: 46, rotation: -18, depth: 0.45 },
  { char: "J", x: 16, y: 26, size: 82, rotation: 24, depth: 0.8 },
  { char: "V", x: 7, y: 43, size: 32, rotation: -8, depth: 0.35 },
  { char: "I", x: 14, y: 61, size: 58, rotation: 17, depth: 0.65 },
  { char: "D", x: 6, y: 76, size: 96, rotation: -24, depth: 0.9 },
  { char: "E", x: 20, y: 87, size: 38, rotation: 12, depth: 0.4 },

  { char: "T", x: 28, y: 8, size: 34, rotation: 15, depth: 0.35 },
  { char: "O", x: 38, y: 12, size: 72, rotation: -28, depth: 0.75 },
  { char: "E", x: 47, y: 6, size: 42, rotation: 21, depth: 0.45 },
  { char: "D", x: 57, y: 13, size: 94, rotation: -12, depth: 0.9 },
  { char: "I", x: 69, y: 7, size: 38, rotation: 31, depth: 0.4 },
  { char: "T", x: 82, y: 14, size: 64, rotation: -19, depth: 0.7 },
  { char: "A", x: 92, y: 8, size: 40, rotation: 13, depth: 0.4 },

  { char: "C", x: 27, y: 27, size: 54, rotation: -21, depth: 0.55 },
  { char: "U", x: 35, y: 34, size: 31, rotation: 18, depth: 0.3 },
  { char: "T", x: 65, y: 31, size: 48, rotation: -14, depth: 0.5 },
  { char: "S", x: 76, y: 27, size: 88, rotation: 25, depth: 0.85 },
  { char: "V", x: 89, y: 34, size: 34, rotation: -31, depth: 0.35 },

  { char: "F", x: 26, y: 48, size: 86, rotation: 16, depth: 0.85 },
  { char: "R", x: 36, y: 55, size: 43, rotation: -27, depth: 0.45 },
  { char: "A", x: 65, y: 48, size: 35, rotation: 22, depth: 0.35 },
  { char: "M", x: 76, y: 50, size: 68, rotation: -17, depth: 0.7 },
  { char: "E", x: 91, y: 49, size: 52, rotation: 29, depth: 0.55 },

  { char: "P", x: 25, y: 68, size: 44, rotation: -14, depth: 0.4 },
  { char: "L", x: 34, y: 76, size: 76, rotation: 27, depth: 0.75 },
  { char: "A", x: 45, y: 84, size: 36, rotation: -22, depth: 0.35 },
  { char: "Y", x: 60, y: 78, size: 92, rotation: 18, depth: 0.9 },
  { char: "S", x: 73, y: 73, size: 42, rotation: -25, depth: 0.45 },
  { char: "H", x: 86, y: 78, size: 70, rotation: 16, depth: 0.7 },
  { char: "O", x: 96, y: 69, size: 34, rotation: -11, depth: 0.35 },

  { char: "A", x: 28, y: 94, size: 64, rotation: 21, depth: 0.6 },
  { char: "J", x: 40, y: 93, size: 30, rotation: -18, depth: 0.3 },
  { char: "V", x: 55, y: 95, size: 52, rotation: 28, depth: 0.55 },
  { char: "E", x: 70, y: 91, size: 78, rotation: -21, depth: 0.8 },
  { char: "R", x: 84, y: 94, size: 40, rotation: 14, depth: 0.4 },
]

function App() {
  const contactRef = useRef<HTMLElement>(null)
  const [scrollY, setScrollY] = useState(0)

  const [cursor, setCursor] = useState({ x: 50, y: 50 })

  const [site, setSite] = useState<SiteContent | null>(null)
  const [sections, setSections] = useState<Section[]>([])
  const [activeSection, setActiveSection] = useState<Section | null>(null)

  const [showLogin, setShowLogin] = useState(false)
  const [showAdmin, setShowAdmin] = useState(false)

  const loadPublicContent = () => {
    fetchPublicSite()
      .then(setSite)
      .catch(() => {
        /* site falls back to the loading state; the hero just stays blank */
      })
    fetchPublicSections()
      .then(setSections)
      .catch(() => {
        /* sidebar stays empty if the backend is unreachable */
      })
  }

  useEffect(() => {
    loadPublicContent()
  }, [])

  useEffect(() => {
    let ticking = false

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setScrollY(window.scrollY)
          ticking = false
        })

        ticking = true
      }
    }

    handleScroll()

    window.addEventListener("scroll", handleScroll, { passive: true })

    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  useEffect(() => {
    const handlePointerMove = (event: PointerEvent) => {
      const x = (event.clientX / window.innerWidth) * 100
      const y = (event.clientY / window.innerHeight) * 100

      setCursor({ x, y })
    }

    window.addEventListener("pointermove", handlePointerMove, { passive: true })

    return () => {
      window.removeEventListener("pointermove", handlePointerMove)
    }
  }, [])

  const scrollProgress = Math.min(scrollY / Math.max(window.innerHeight, 1), 1)

  const faceParallaxY = Math.min(scrollY * -0.045, -28)
  const faceParallaxX = Math.sin(scrollProgress * Math.PI) * 22
  const faceScale = 1 + scrollProgress * 0.055

  const identityY = 0

  const scrollBlur = Math.min(scrollProgress * 2.5, 2.5)
  const scrollOpacity = 1 - scrollProgress * 0.08

  const scrollStyle = {
    "--face-parallax-x": `${faceParallaxX}px`,
    "--face-parallax-y": `${faceParallaxY}px`,
    "--face-scale": faceScale,
    "--scene-blur": `${scrollBlur}px`,
    "--scene-opacity": scrollOpacity,
    "--identity-y": `${identityY}px`,
  } as React.CSSProperties

  const scrollToContact = () => {
    contactRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleAdminTrigger = () => {
    if (isLoggedIn()) {
      setShowAdmin(true)
    } else {
      setShowLogin(true)
    }
  }

  const handleLoginSuccess = () => {
    setShowLogin(false)
    setShowAdmin(true)
  }

  return (
    <div className="site">
      <div
        className="hero-background"
        style={scrollStyle}
      >
        <div
          className="hero-background__atmosphere"
          aria-hidden="true"
        />

        <div
          className="hero-background__letters"
          aria-hidden="true"
        >
          {floatingLetters.map((letter, index) => {
            const dx = cursor.x - letter.x
            const dy = cursor.y - letter.y

            const moveX = dx * 0.16 * letter.depth
            const moveY = dy * 0.16 * letter.depth

            return (
              <span
                key={`${letter.char}-${index}`}
                className="hero-background__letter"
                style={{
                  left: `${letter.x}%`,
                  top: `${letter.y}%`,
                  fontSize: `${letter.size}px`,
                  transform: `
                    translate(-50%, -50%)
                    translate3d(${moveX}px, ${moveY}px, 0)
                    rotate(${letter.rotation}deg)
                  `,
                  opacity: 0.12 + letter.depth * 0.14,
                }}
              >
                {letter.char}
              </span>
            )
          })}
        </div>

        <div className="hero-background__content">
          <div className="hero-background__face-float">
            <img
              src="/art/athang-face.png"
              alt={site?.heroName ?? "Athang Jadhav"}
              className="hero-background__face"
            />
          </div>

          <div className="hero-background__identity">
            <h1>{site?.heroName ?? "Athang Jadhav"}</h1>
            <p>{site?.heroRole ?? "Video Editor"}</p>
          </div>
        </div>

        <div
          className="hero-background__scroll-hint"
          style={{ opacity: scrollY > 80 ? 0 : 1 }}
          aria-hidden="true"
        >
          <span>Scroll to view</span>
          <span className="hero-background__scroll-line" />
        </div>
      </div>

      <TopBar
        onContactClick={scrollToContact}
        onAdminTrigger={handleAdminTrigger}
      />

      <main className="page-content">
        <section
          className="hero-spacer"
          aria-hidden="true"
        />

        <section
          className="portfolio"
          id="work"
        >
          <div className="portfolio__intro">
            <p>{site?.introEyebrow ?? "Selected Work"}</p>

            <h2>{site?.introHeading ?? "Things I've edited."}</h2>
          </div>

          <div className="portfolio__layout">
            <WorkSidebar
              sections={sections}
              onSelect={setActiveSection}
            />
          </div>
        </section>

        <section
          className="pricing"
          id="pricing"
        >
          <div className="pricing__intro">
            <p>Pricing</p>

            <h2>
              Simple plans.
              <br />
              Clear value.
            </h2>

            <p className="pricing__description">
              Choose a one-off edit or a recurring plan depending on how
              often you publish.
            </p>
          </div>

          <div className="pricing__plans">
            <article className="pricing-card">
              <div className="pricing-card__top">
                <span>01</span>
                <h3>Single Short</h3>
              </div>

              <div className="pricing-card__price">
                <strong>₹1,000</strong>
                <span>/ video</span>
              </div>

              <ul>
                <li>1 short-form edit</li>
                <li>Cuts, captions &amp; basic graphics</li>
                <li>Turnaround: 2–3 days</li>
                <li>1 round of minor changes</li>
              </ul>
            </article>

            <article className="pricing-card pricing-card--featured">
              <div className="pricing-card__top">
                <span>02</span>
                <h3>Weekly</h3>
              </div>

              <p className="pricing-card__quantity">4 shorts / week</p>

              <div className="pricing-card__price">
                <div>
                  <del>₹4,000</del>
                  <strong>₹3,200</strong>
                </div>

                <span>/ week</span>
              </div>

              <p className="pricing-card__discount">~20% retainer discount</p>

              <ul>
                <li>4 shorts every week</li>
                <li>Each short delivered within 2–3 days of being sent</li>
                <li>1 round of revisions per video</li>
              </ul>
            </article>

            <article className="pricing-card">
              <div className="pricing-card__top">
                <span>03</span>
                <h3>Monthly</h3>
              </div>

              <p className="pricing-card__quantity">16 shorts / month</p>

              <div className="pricing-card__price">
                <div>
                  <del>₹16,000</del>
                  <strong>₹13,000</strong>
                </div>

                <span>/ month</span>
              </div>

              <p className="pricing-card__discount">~20% retainer discount</p>

              <ul>
                <li>16 shorts every month</li>
                <li>Each short delivered within 2–3 days of being sent</li>
                <li>1–2 rounds of revisions per video</li>
              </ul>
            </article>
          </div>

          <p className="pricing__note">
            Revisions cover cut, caption, and music adjustments — not new
            edits or a different creative direction. Client supplies the raw
            footage, B-roll, and music.
          </p>
        </section>

        <section
          className="contact"
          ref={contactRef}
          id="contact"
        >
          <p className="contact__eyebrow">
            {site?.contactEyebrow ?? "Have a project in mind?"}
          </p>

          <h2>{site?.contactHeading ?? "Let's work together."}</h2>

          <p className="contact__description">
            {site?.contactDescription ?? "Send me your raw footage."}
          </p>

          <a
            className="contact__email"
            href={`mailto:${site?.contactEmail ?? "editswithathang@gmail.com"}`}
          >
            {site?.contactEmail ?? "editswithathang@gmail.com"}
          </a>
        </section>
      </main>

      {activeSection && (
        <VideoModal
          section={activeSection}
          onClose={() => setActiveSection(null)}
        />
      )}

      {showLogin && (
        <LoginModal
          onClose={() => setShowLogin(false)}
          onSuccess={handleLoginSuccess}
        />
      )}

      {showAdmin && (
        <AdminDashboard
          onClose={() => setShowAdmin(false)}
          onContentChanged={loadPublicContent}
        />
      )}
    </div>
  )
}

export default App
