// Central place for talking to the backend. Keeps the API base URL,
// the admin token, and fetch error handling in one spot so components
// don't repeat it.

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000"
const TOKEN_KEY = "admin_token"

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY)
}

export function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token)
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY)
}

export function isLoggedIn(): boolean {
  return Boolean(getToken())
}

async function parseJsonSafely(response: Response) {
  const text = await response.text()
  if (!text) return null
  try {
    return JSON.parse(text)
  } catch {
    return null
  }
}

async function request(path: string, options: RequestInit = {}) {
  const response = await fetch(`${API_URL}${path}`, options)
  const body = await parseJsonSafely(response)

  if (!response.ok) {
    const message =
      (body && typeof body === "object" && "error" in body && String(body.error)) ||
      `Request failed (${response.status})`
    throw new Error(message)
  }

  return body
}

function authHeaders(): Record<string, string> {
  const token = getToken()
  return token ? { Authorization: `Bearer ${token}` } : {}
}

// ---- Public endpoints ----

export type Section = {
  id: string
  title: string
  caption: string
  videoUrl: string | null
  isVisible: boolean
  position: number
  createdAt: string
  updatedAt: string
}

export type SiteContent = {
  heroName: string
  heroRole: string
  introEyebrow: string
  introHeading: string
  contactEyebrow: string
  contactHeading: string
  contactDescription: string
  contactEmail: string
}

export function fetchPublicSections(): Promise<Section[]> {
  return request("/api/sections")
}

export function fetchPublicSite(): Promise<SiteContent> {
  return request("/api/site")
}

export function mediaUrl(path: string | null): string | null {
  if (!path) return null
  return `${API_URL}${path}`
}

// ---- Auth ----

export async function login(password: string): Promise<void> {
  const data = await request("/api/admin/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ password }),
  })
  setToken(data.token)
}

export function logout() {
  clearToken()
}

// ---- Admin endpoints ----

export function fetchAdminSections(): Promise<Section[]> {
  return request("/api/admin/sections", { headers: authHeaders() })
}

export function fetchAdminSite(): Promise<SiteContent> {
  return request("/api/admin/site", { headers: authHeaders() })
}

export function updateSite(updates: Partial<SiteContent>): Promise<SiteContent> {
  return request("/api/admin/site", {
    method: "PUT",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify(updates),
  })
}

type SectionFormInput = {
  title: string
  caption: string
  isVisible: boolean
  videoFile?: File | null
}

function buildSectionFormData(input: SectionFormInput): FormData {
  const formData = new FormData()
  formData.append("title", input.title)
  formData.append("caption", input.caption)
  formData.append("isVisible", String(input.isVisible))
  if (input.videoFile) {
    formData.append("video", input.videoFile)
  }
  return formData
}

export function createSection(input: SectionFormInput): Promise<Section> {
  return request("/api/admin/sections", {
    method: "POST",
    headers: authHeaders(),
    body: buildSectionFormData(input),
  })
}

export function updateSection(id: string, input: Partial<SectionFormInput>): Promise<Section> {
  const formData = new FormData()
  if (input.title !== undefined) formData.append("title", input.title)
  if (input.caption !== undefined) formData.append("caption", input.caption)
  if (input.isVisible !== undefined) formData.append("isVisible", String(input.isVisible))
  if (input.videoFile) formData.append("video", input.videoFile)

  return request(`/api/admin/sections/${id}`, {
    method: "PUT",
    headers: authHeaders(),
    body: formData,
  })
}

export function deleteSection(id: string): Promise<void> {
  return request(`/api/admin/sections/${id}`, {
    method: "DELETE",
    headers: authHeaders(),
  })
}

export function reorderSections(order: string[]): Promise<Section[]> {
  return request("/api/admin/sections/reorder", {
    method: "PUT",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify({ order }),
  })
}
